/*
  Von Paula und Islam geschrieben und bearbeitet.
*/
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "raylib.h"

int main(){
    
    const int screenWidth = 2000;
    const int screenHeight = 1000;
    InitWindow(screenWidth, screenHeight, "highscore-list");
    
    Texture2D Background = LoadTexture ("resouces/background2.png");
    Texture2D texture2 = LoadTextureFromImage(background2);
    UnloadImage(background2);
    
    const char message[128] = "YAY! YOU WIN! :D";
    int framesCounter = 0;
        
    int highscore[5];
    int score = 0;
    char vari[10];

    SetTargetFPS(60); 
    
    // Der Teil von Islam: Zeilen 28-54.
    for(int i = 0; i<5; i++){
        char dateiname [10];
        sprintf(dateiname, "highscore%d.txt", i);
        FILE *datei;
        datei = fopen(dateiname, "a+");
        fscanf(datei, "%s", vari); // Einlese
        highscore[i] = atoi(vari); // char string ind int umformen
        fclose(datei);
    }

if(highscore[4]< score){
    highscore[4] = score;
    for(int i = 3; highscore[i] < score; i-- ){
        highscore[i+1] = highscore [i];
        highscore [i] = score;
    }
    
    for(int i = 0; i<5; i++){
        char dateiname [10];
        sprintf(dateiname, "highscore%d.txt", i);
        FILE *datei;
        datei = fopen(dateiname, "a+");
        fprintf(datei,"%d", highscore[i]);
        fclose(datei);
        }
    }      

    while (!WindowShouldClose()){   
        // Update
        if (IsKeyDown(KEY_SPACE)) framesCounter += 8;
        else framesCounter++;

        if (IsKeyPressed(KEY_ENTER)) framesCounter = 0;
        for(int i=0; i<5; i++){

        BeginDrawing();
        
            ClearBackground(RAYWHITE);
            DrawTexture(texture2, screenWidth/2 - texture2.width/2, screenHeight/2 - texture2.height/2, WHITE);
            DrawText(TextSubtext(message, 0, framesCounter/5), 550, 400, 100, MAROON);

            DrawText(TextFormat("DEIN SCORE: %d", score), 280, 130, 40, BLACK);
            DrawText(TextFormat("HIGH-SCORE: %d. %d\n", i++, highscore[1]), 210, 200, 50, BLACK);
            
        EndDrawing();
        }
    }
    
    CloseWindow();

return 0;
}
