// Wir haben die main.c Datei in drei Teilen unterteilt.
#include "raylib.h"
#include "raymath.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>


#define MAX_FRAME_SPEED  16
#define MIN_FRAME_SPEED  1

static int framesCounter;

typedef enum { TITLE, GAMEPLAY, ENDING } GameScreen;

static RenderTexture2D screenTarget = { 0 };

int currentFrame = 0;

int framesSpeed = 5;
    
static const int screenWidth = 1920;
static const int screenHeight = 1080;

int BackgroundX = 0;
int BackgroundY = 0;
int PlayerX = 0.0f;
int PlayerY = 550.0f;
int PlayerW = 20;
int PlayerH = 10;
int LiftX = 550.0f;
int LiftY = 780.0f;
int LiftW = 150;
int LiftH = 20;
int moveX = 7;

/*int FloorX = 0;
int FloorY = 400;
int FloorW = 2000;
int FloorH = 80;*/

bool Fly;
int FlyTimer;


int main(void)
{
static bool exitGame = false;
static Font font = { 0 };
Music music = { 0 };

/*
    Bis zu der while Schleife hat Paula die Physik und Interface organisiert, die im Bereich "Game Screen" benutzt werden. Andriy hat den Sprite-Sheet zum Player und den Aufzug gemacht.
*/
    InitWindow(screenWidth, screenHeight, "Lone Digger");
    InitAudioDevice();
    screenTarget = LoadRenderTexture(640, 480);
    Vector2 BackgroundPosition = { BackgroundX, BackgroundY };
    Texture2D Background = LoadTexture ("resources/background1_2.png"); 
    Texture2D title = LoadTexture("resources/title.png");
    Rectangle BackgroundFrameRec = { 0.0f , 0.0f, (float)Background.width, (float)Background.height };
   // Rectangle floor = { FloorX, FloorY, FloorW, FloorH};

    Vector2 position = { PlayerX, PlayerY };
    Vector2 LiftPosition = { LiftX, LiftY };
    Texture2D Player = LoadTexture ("resources/Player1.png");
    Texture2D Lift = LoadTexture ("resources/lift.png");
    Rectangle frameRec = { 0.0f , 0.0f, (float)Player.width/12, (float)Player.height};
    Rectangle LiftFrameRec = { 0.0f , 0.0f, (float)Lift.width, (float)Lift.height };

    font  = LoadFont("resources/komika.png");
    music = LoadMusicStream("resources/audio/Minecraft.wav");

    SetMusicVolume(music, 1.0f);

    GameScreen currentScreen = TITLE;

    screenTarget = LoadRenderTexture(640, 480);

    static int timeLevelSeconds = 300;
    static int score = 1000;
    static int hiscore = 0;

    SetTargetFPS(60);  

/*
   Von Andriy bearbeitet.
*/

    while (!WindowShouldClose() && !exitGame)  
    {   
        Rectangle foot = {position.x+50, position.y+450, PlayerW, PlayerH}; 
        Rectangle lift = {LiftX+305, LiftY+215, LiftW, LiftH};
        bool platformCollision = CheckCollisionRecs(foot, lift);
        DrawTextureRec(Background, BackgroundFrameRec, BackgroundPosition, WHITE);
        PlayMusicStream(music);

        framesCounter++;

        switch (currentScreen)
        {
            case TITLE:
            {
                if (IsKeyPressed(KEY_ENTER))
                {
                    currentScreen = GAMEPLAY;
                    framesCounter = 0;
                }

            } break;

            case GAMEPLAY: {
            
        if(IsKeyDown(KEY_RIGHT)){
            position.x +=moveX;
        if (framesCounter >= (60/framesSpeed))
        {
            framesCounter = 0;
            currentFrame++;

            if (currentFrame > 5) currentFrame = 0;

            frameRec.x = (float)currentFrame*(float)Player.width/12;
        }
        }

        if(IsKeyDown(KEY_D)){
            position.x +=moveX;
        if (framesCounter >= (60/framesSpeed))
        {
            framesCounter = 0;
            currentFrame++;

            if (currentFrame > 5) currentFrame = 0;

            frameRec.x = (float)currentFrame*(float)Player.width/12;
        }
        }

        if(IsKeyDown(KEY_LEFT)){
            position.x -=moveX;
        if (framesCounter >= (60/framesSpeed))
        {
            framesCounter = 0;
            currentFrame++;

            if (currentFrame > 11) currentFrame = 6;

            frameRec.x = (float)currentFrame*(float)Player.width/12;
        }
        }

        if(IsKeyDown(KEY_A)){
            position.x -=moveX;
        if (framesCounter >= (60/framesSpeed))
        {
            framesCounter = 0;
            currentFrame++;

            if (currentFrame > 11) currentFrame = 6;

            frameRec.x = (float)currentFrame*(float)Player.width/12;
        }
        }

        if (framesSpeed > MAX_FRAME_SPEED) framesSpeed = MAX_FRAME_SPEED;
        else if (framesSpeed < MIN_FRAME_SPEED) framesSpeed = MIN_FRAME_SPEED;

        framesCounter++;

                if (framesCounter == 60)
                {
                    timeLevelSeconds--;
                    framesCounter = 0;
                    if (timeLevelSeconds == 0)
                    {
                        currentScreen = ENDING;
                    }
                }

        if(platformCollision){

            Fly = false; // zu true ändern
            
            DrawText("Success", 10, 25, 20, WHITE);
        }

        if(Fly){
            FlyTimer += 1;
            if (FlyTimer < 400){
                position.y -= 2;
            }
        }

        
        if(IsKeyDown(KEY_E)){
        
        currentScreen = ENDING;
         framesCounter = 0;

         if (score > hiscore) hiscore = score;
        }

            } break;

            case ENDING:
            {
                if (IsKeyPressed(KEY_ENTER))
                {
                    currentScreen = TITLE;
                    score = 1000;
                    framesCounter = 0;
                }

            } break;
            default: break;
        }

        if (currentScreen != ENDING) UpdateMusicStream(music);

        BeginDrawing();

            ClearBackground(RAYWHITE);
          //DrawRectangleRec(floor, ORANGE);
            DrawTextureRec(Player, frameRec, position, WHITE);
            DrawTextureRec(Lift, LiftFrameRec, LiftPosition, WHITE);
          //DrawRectangleRec(foot, GOLD);
          //DrawRectangleRec(lift, BLUE);
            
            /*
             Islam und Andriy haben die switch Funktion gemeinsam gebastelt in dem wir die optimale Eingaben(Parameter) ausgesucht haben.
             Andriy hat bei Bedarf in der while Schleife die Parameter von currentScreen geschrieben während Islam diese optimisiert hat.
            */

            switch (currentScreen){

                case TITLE:
                {
                    DrawTexture(title, screenWidth/2 - title.width/2, screenHeight/2 - title.height/2 - 80, WHITE);

                    if ((framesCounter/30) % 2) DrawTextEx(font, "PRESS ENTER", (Vector2){ screenWidth/2 - 150, 480 }, font.baseSize, 0, WHITE);

                } break;

            case GAMEPLAY:
            {
            DrawTextEx(font, TextFormat("SCORE: %04i", score), (Vector2){ screenWidth - 300, 20 }, font.baseSize, -2, ORANGE);
            DrawTextEx(font, TextFormat("TIME: %i:%02is", timeLevelSeconds/60, timeLevelSeconds%60), (Vector2){ screenHeight - 300, 20 }, font.baseSize, 1, ORANGE);
            } break;

            case ENDING:
                {
                    
                    DrawRectangle(0, 0, screenWidth, screenHeight, Fade(BLACK, 0.4f));

                    DrawTextEx(font, "GAME OVER", (Vector2){ 300, 160 }, font.baseSize*3, -2, MAROON);

                    DrawTextEx(font, TextFormat("SCORE: %04i", score), (Vector2){ 680, 350 }, font.baseSize, -2, GOLD);
                    DrawTextEx(font, TextFormat("HISCORE: %04i", hiscore), (Vector2){ 665, 400 }, font.baseSize, -2, ORANGE);

                    if ((framesCounter/30) % 2) DrawTextEx(font, "PRESS ENTER to REPLAY", (Vector2){ screenWidth/2 - 250, 520 }, font.baseSize, -2, LIGHTGRAY);

                } break;
                  default: break;
            
            }
 

        EndDrawing();
       
    }

    UnloadTexture(Background);  
    UnloadTexture(Player);    
    UnloadFont(font);
    CloseAudioDevice();
    CloseWindow();

    return 0;
}
