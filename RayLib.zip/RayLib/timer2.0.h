/*
  Von Islam geschrieben und bearbeitet.
*/
#include <Windows.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int timer()
{
int time = 0;
int sec = 1;
int sprung = 0;
int score = 0;
int height = 0;
int arr[20];



    while(1){
        if(sprung > 0)
            sprung--;
        time++;
        clock_t ende = clock() + sec * CLOCKS_PER_SEC/100;
        system("cls");

        if(height < 3 && arr[20] == 1)
            break;

        score = clock()*10/CLOCKS_PER_SEC;
        printf("\t\tScore: &d", score);


    }


return 0;
}