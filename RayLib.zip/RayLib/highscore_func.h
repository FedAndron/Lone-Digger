/*
  Von Islam geschrieben und bearbeitet.
*/
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

int highscore()
{
int highscore[5];
int score = 0;
char vari[10];
for(int i = 0; i<5; i++){
    char dateiname [10]; 
    sprintf(dateiname, "highscore%d.txt", i);
    FILE *datei;
    datei = fopen(dateiname, "a+");
    fscanf(datei, "%s", vari); // Einlese
    highscore[i] = atoi(vari); // char string ind int umformen
    fclose(datei);
}

if(highscore[4]< score){
    highscore[4] = score;
    for(int i = 3; highscore[i] < score; i-- ){
        highscore[i+1] = highscore [i];
        highscore [i] = score;
    }
    for(int i = 0; i<5; i++){
        char dateiname [10]; 
        sprintf(dateiname, "highscore%d.txt", i);
        FILE *datei;
        datei = fopen(dateiname, "a+");
        fprintf(datei,"%d", highscore[i]);
        fclose(datei);
    }
}

printf("LEADERBOARD:\n");
for(int i = 0; i<5; i++)
    printf("%d. %d\n", i+1, highscore [i]);
printf("Dein Score: %d", score);


return 0;
}